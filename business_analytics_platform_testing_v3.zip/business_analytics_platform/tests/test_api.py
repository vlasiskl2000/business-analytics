import uuid


def register_and_login(client):
    username = f"test_{uuid.uuid4().hex[:8]}"
    password = "StrongPass123!"

    response = client.post(
        "/api/register",
        params={"username": username, "password": password},
    )
    assert response.status_code == 200
    assert response.json()["success"] is True

    response = client.post(
        "/api/login",
        params={"username": username, "password": password},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["token_type"] == "bearer"
    return username, {"Authorization": f"Bearer {body['access_token']}"}


def test_protected_endpoint_requires_authentication(client):
    response = client.get("/api/kpis")
    assert response.status_code in (401, 403)


def test_authentication_and_kpis(client):
    _, headers = register_and_login(client)

    response = client.get("/api/auth-test", headers=headers)
    assert response.status_code == 200
    assert response.json()["success"] is True

    response = client.get("/api/kpis", headers=headers)
    assert response.status_code == 200
    body = response.json()
    assert body["total_revenue"] > 0
    assert body["total_cost"] > 0
    assert body["total_profit"] == body["total_revenue"] - body["total_cost"]


def test_simulator_zero_change_matches_current_values(client):
    _, headers = register_and_login(client)

    kpis = client.get("/api/kpis", headers=headers).json()
    scenario = client.get(
        "/api/simulator",
        params={"price_change": 0, "unit_change": 0, "cost_change": 0},
        headers=headers,
    )

    assert scenario.status_code == 200
    body = scenario.json()
    assert body["scenario"]["revenue"] == kpis["total_revenue"]
    assert body["scenario"]["cost"] == kpis["total_cost"]
    assert body["scenario"]["profit"] == kpis["total_profit"]


def test_simulator_rejects_invalid_values(client):
    _, headers = register_and_login(client)

    response = client.get(
        "/api/simulator",
        params={"price_change": 1000},
        headers=headers,
    )
    assert response.status_code == 400


def test_goals_are_user_scoped(client):
    _, headers = register_and_login(client)

    response = client.post(
        "/api/goals",
        params={"metric": "revenue", "target": 100000},
        headers=headers,
    )
    assert response.status_code == 200
    assert response.json()["success"] is True

    response = client.get("/api/goals", headers=headers)
    assert response.status_code == 200
    goals = response.json()["goals"]
    assert len(goals) == 1
    assert goals[0]["metric"] == "revenue"
    assert goals[0]["target"] == 100000


def test_dashboard_widget_data_uses_sales_column(client):
    _, headers = register_and_login(client)

    response = client.post(
        "/api/dashboard/widgets",
        params={
            "title": "Revenue by Product",
            "widget_type": "bar",
            "metric": "revenue",
            "dimension": "product",
        },
        headers=headers,
    )
    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    widget_id = body["id"]

    response = client.get(
        f"/api/dashboard/widget-data/{widget_id}",
        headers=headers,
    )
    assert response.status_code == 200
    data = response.json()["data"]
    assert data
    assert all("label" in row and "value" in row for row in data)
    assert all(row["value"] >= 0 for row in data)


def test_report_data(client):
    _, headers = register_and_login(client)

    response = client.get("/api/report-data", headers=headers)
    assert response.status_code == 200
    body = response.json()
    assert "kpis" in body
    assert "top_product" in body
    assert "top_region" in body
    assert "anomalies" in body
